import PAGES.LogInPage;
import PAGES.ProductsPage;
import PAGES.YourCartPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SuccessfulAddToCartTest  {

     static WebDriver driver;

    LogInPage login=new LogInPage(driver);
    ProductsPage productpage=new ProductsPage(driver);

    YourCartPage yourcart=new YourCartPage(driver);

    public static void setDriver(WebDriver driver) {
        SuccessfulAddToCartTest.driver = driver;
    }
    @BeforeClass
    public static void beforeClass() throws Exception {
        WebDriverManager.chromedriver().setup();
        driver=new ChromeDriver();
        driver.manage().window().maximize();
    }

    @AfterClass
    public static void afterClass() throws Exception {
        driver.quit();
    }
    @Before
    public void setUp() throws Exception {
        driver.get("https://www.saucedemo.com/");
        login.validLogIn();
    }

    @After
    public void tearDown() throws Exception {
        Thread.sleep(1000);
    }

    @Test
    public void successfulAddToCartTest() {
        driver.findElement(productpage.addToCartSauceLabsBackPack).click();
        driver.findElement(productpage.addToCartSauceLabsFleeceJacket).click();
        driver.findElement(productpage.cartIconButton).click();
        String expectedItemOne="Sauce Labs Backpack";
        String expectedItemTwo="Sauce Labs Fleece Jacket";
        String realItemOne=driver.findElement(yourcart.sauceLabsBackPackItem).getText();
        String realItemTwo=driver.findElement(yourcart.sauceLabsFleeceJacketItem).getText();
        Assert.assertTrue("pogresan predmet dodat",realItemOne.equals(expectedItemOne));
        Assert.assertTrue("pogresan predmet dodat",expectedItemTwo.equals(realItemTwo));





    }
}
