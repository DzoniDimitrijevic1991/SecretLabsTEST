import PAGES.LogInPage;
import PAGES.ProductsPage;
import PAGES.YourCartPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SabiranjeCenaTest {

    static WebDriver driver;

    LogInPage login = new LogInPage(driver);
    ProductsPage productpage = new ProductsPage(driver);

    YourCartPage yourcart = new YourCartPage(driver);

    @BeforeClass
    public static void beforeClass() throws Exception {
        WebDriverManager.chromedriver().setup();
        driver=new ChromeDriver();
        driver.manage().window().maximize();
    }

    @AfterClass
    public static void afterClass() throws Exception {
        driver.quit();
    }

    @Before
    public void setUp() throws Exception {
        driver.get("https://www.saucedemo.com/");
    }

    @After
    public void tearDown() throws Exception {
        Thread.sleep(1000);
    }

    @Test
    public void sabiranjeCenaTest() {
        login.validLogIn();
        driver.findElement(productpage.addToCartSauceLabsBackPack).click();
        driver.findElement(productpage.addToCartSauceLabsFleeceJacket).click();
        driver.findElement(productpage.cartIconButton).click();
        double itemOnePrice= yourcart.priceForSauceLabsBackPack;
        double itemTwoPrice= yourcart.priceForSauceLabsFleeceJacket;
        double expectedOnePlusTwoPrice= itemOnePrice + itemTwoPrice;
        System.out.println(expectedOnePlusTwoPrice);

    }
}
