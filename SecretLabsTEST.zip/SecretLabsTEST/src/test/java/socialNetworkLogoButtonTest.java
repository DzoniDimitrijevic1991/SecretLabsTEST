import PAGES.LogInPage;
import PAGES.ProductsPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.JavascriptExecutor;

public class socialNetworkLogoButtonTest  {

    protected static WebDriver driver;

    JavascriptExecutor js = (JavascriptExecutor) driver;

    LogInPage login=new LogInPage(driver);
    ProductsPage productpage=new ProductsPage(driver);





    @BeforeClass
    public static void beforeClass() throws Exception {
        WebDriverManager.chromedriver().setup();
        driver=new ChromeDriver();
        driver.manage().window().maximize();
    }

    @AfterClass
    public static void afterClass() throws Exception {
        driver.quit();
    }

    @Before
    public void setUp() throws Exception {
        driver.get("https://www.saucedemo.com/");
        login.validLogIn();
    }

    @After
    public void tearDown() throws Exception {
        Thread.sleep(1000);
    }

    @Test
    public void twitterLogoButtonTest() throws InterruptedException {

        js.executeScript("window.scrollBy(0,250)", "");
        driver.findElement(productpage.twitterLogoButton).click();
        Thread.sleep(2000);
        String expectedPageUrl="https://twitter.com/saucelabs";
        String realTitle=driver.getCurrentUrl();
        System.out.println(realTitle);
        Assert.assertTrue("pogresan url",expectedPageUrl.equals(realTitle));
        //umesto ocekivanog url-a https://twitter.com/saucelabs otvara se stranica https://www.saucedemo.com/inventory.html

    }

    @Test
    public void facebookLogoButtonTest() throws InterruptedException {

        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0,250)", "");
        driver.findElement(productpage.facebookLogoButton).click();
        Thread.sleep(2000);
        String expectedPageText="Facebook";
        String realPageText=driver.findElement(productpage.facebookTextLogo).getText();
        System.out.println(realPageText);
        Assert.assertTrue("pogresan text",expectedPageText.equals(realPageText));
    }

    @Test
    public void linkeInPageTest() {
        js.executeScript("window.scrollBy(0,250)", "");
        driver.findElement(productpage.linkedInLogoButton).click();
        String expectedPageUrl="https://www.linkedin.com/company/sauce-labs/";
        String realPageUrl=driver.getCurrentUrl();
        System.out.println(realPageUrl);
        Assert.assertTrue("pogresan url",expectedPageUrl.equals(realPageUrl));
//umesto ocekivanog url-a https://www.linkedin.com/company/sauce-labs/ otvara se stranica https://www.saucedemo.com/inventory.html
    }
}
