import PAGES.LogInPage;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LogInPageTest  {

    protected static WebDriver driver;

    LogInPage login=new LogInPage(driver);

    @BeforeClass
    public static void beforeClass() throws Exception {
        WebDriverManager.chromedriver().setup();
        driver=new ChromeDriver();
        driver.manage().window().maximize();
    }

    @AfterClass
    public static void afterClass() throws Exception {
        driver.quit();
    }

    @Before
    public void setUp() throws Exception {
        driver.get("https://www.saucedemo.com/");

    }

    @After
    public void tearDown() throws Exception {
        Thread.sleep(1000);
    }

    @Test
    public void testValidUserNameAndPassword() {
        login.validLogIn();
        String logInPageExpected="https://www.saucedemo.com/inventory.html";
        String realLogInPage= driver.getCurrentUrl();
        Assert.assertTrue("neuspesan log in",logInPageExpected.equals(realLogInPage));

    }

    @Test
    public void testInvalidUserNameValidPassword() {

        login.enterUserName("Nikola");
        login.enterPassword("secret_sauce");
        driver.findElement(login.logInButton).click();
        String expectedMessageAfterLogInFailed="Epic sadface: Username and password do not match any user in this service";
        String realMessageAfterLogInFailed=driver.findElement(login.textMessageAfterLogInFailed).getText();
        Assert.assertTrue("uspesan log in",expectedMessageAfterLogInFailed.equals(realMessageAfterLogInFailed));
    }

    @Test
    public void testValidUserNameInvalidPassword() {
        login.enterUserName("standard_user");
        login.enterPassword("Nikola");
        driver.findElement(login.logInButton).click();
        String expectedMessageAfterLogInFailed="Epic sadface: Username and password do not match any user in this service";
        String realMessageAfterLogInFailed=driver.findElement(login.textMessageAfterLogInFailed).getText();
        Assert.assertTrue("uspesan log in",expectedMessageAfterLogInFailed.equals(realMessageAfterLogInFailed));
    }

    @Test
    public void testInvalidUserNameInvalidPassword() {
        login.enterUserName("Nikola");
        login.enterPassword("Dimitrijevic");
        driver.findElement(login.logInButton).click();
        String expectedMessageAfterLogInFailed="Epic sadface: Username and password do not match any user in this service";
        String realMessageAfterLogInFailed=driver.findElement(login.textMessageAfterLogInFailed).getText();
        Assert.assertTrue("uspesan log in",expectedMessageAfterLogInFailed.equals(realMessageAfterLogInFailed));

    }

    @Test
    public void testWithoutEnteringUserNameAndPassword() {

        driver.findElement(login.logInButton).click();
        String expectedMessageAfterLogInFailed="Epic sadface: Username is required";
        String realMessageAfterLogInFailed=driver.findElement(login.textMessageAfterLogInWithoutTextInputFailed).getText();
        Assert.assertTrue("uspesan log in",expectedMessageAfterLogInFailed.equals(realMessageAfterLogInFailed));

    }
}
